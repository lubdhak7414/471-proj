import React from 'react';

function NotFoundPage() {
  return (
    <div className='flex justify-center'>
      404 Page Not Found :/
    </div>
  )
} 

export default NotFoundPage